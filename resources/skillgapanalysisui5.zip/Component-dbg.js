sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("skillgapanalysisui5.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);